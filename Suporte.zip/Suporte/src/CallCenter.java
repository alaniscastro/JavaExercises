/*Alanis Viana Castro*/
import java.util.Scanner;

public class CallCenter {
    public static void main(String[] args) 
    {
        SuporteTecnico st = new SuporteTecnico();
        Interpretadora in = new Interpretadora();
        st.setSolucoes();
        st.setSolucaoPadrao();
        Scanner input = new Scanner(System.in);
        System.out.println("Bem-vindo ao sistema de Suporte Técnico");
        System.out.println("Pressione <enter> para continuar ou digite 'Sair' para sair do sistema");
        String problema = input.nextLine();
        if (problema.isEmpty())
        {
            System.out.println("Informe seu problema:");
            problema = input.nextLine();
            while((problema.equals("sair")!=true)&&(problema.equals("Sair")!=true))
            {            
                st.buscarSolucao(in.interpretarProblema(problema));
                problema = input.nextLine();
            }
        }
    }
}