/*Alanis Viana Castro*/
import java.util.HashSet;

public class Interpretadora 
{
    private HashSet<String> palavrasChave=new HashSet<String>();
    
    public HashSet<String> interpretarProblema (String problema)
    {
        palavrasChave.clear();
        String [] palavras = problema.split(" ");
        for(String palavra : palavras)
        {
            palavrasChave.add(palavra);
        }
        return palavrasChave;
    }
}