package Exception;

public class SaqueDepositoException extends Exception 
{
    public  SaqueDepositoException()
    {
        super("Valor Inválido");
    }
}
