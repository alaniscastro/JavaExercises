package Exception;

public class NaoTemDinheiroException extends Exception 
{
    public  NaoTemDinheiroException()
    {
        super("Você não possui esse valor disponível");
    }
    
}
