//Alanis Viana Castro e Matheus Freire Henrique Fonseca
package prova1;
import java.util.HashMap;
import java.util.Map;

public class Estoque 
{
    private Map<Integer, Produto> listaprod = new HashMap<Integer, Produto>();
    public void adicionar (Produto produto)
    {
        listaprod.put(produto.getCodigo(), produto);
    }
        
    public Produto encontraProdutoNaLista (int codigo)
    {
        Produto produto = listaprod.get(codigo);
        return produto;
    }
}
