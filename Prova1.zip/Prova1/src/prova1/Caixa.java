//Alanis Viana Castro e Matheus Freire Henrique Fonseca
package prova1;

import java.util.Scanner;

public class Caixa 
{
    public static void main(String[] args) 
    {
        Estoque listaEstoque = new Estoque();
        Scanner input = new Scanner (System.in);
        
        //Criando os produtos e os adicionando a lista de produtos no estoque
        listaEstoque.adicionar(new Produto ("Detergente ABC", 1, 11111));
        listaEstoque.adicionar(new Produto ("Sabão em pó OMO", 6.5 , 22222));
        listaEstoque.adicionar(new Produto ("Shampoo Beleza Fácil", 12, 33333));
        listaEstoque.adicionar(new Produto ("Creme Dental Colgate", 3.5 , 44444));
        listaEstoque.adicionar(new Produto ("Sabonete Nivea", 1.8 , 55555));
        listaEstoque.adicionar(new Produto ("Biscoito Maizena", 2, 66666));
        listaEstoque.adicionar(new Produto ("Leite desnatado Parmalat", 3, 77777));
        
        Venda listavenda = new Venda();
        int codigo=1;
        while (codigo != 0)
        {
            System.out.println("Insira o código do item:");
            codigo = input.nextInt();
            if (codigo != 0)
            {
                Produto p = listaEstoque.encontraProdutoNaLista(codigo);
                if ( p != null )
                {                                        
                    System.out.println("Insira a quantidade de itens:");
                    int quant = input.nextInt();
                    listavenda.adicionar(quant, p);
                    System.out.println("Produto adicionado a lista com sucesso!");
                    System.out.println();
                }
                else
                {
                    System.out.println("Código inválido!");
                    System.out.println();
                }
            }
        }
        System.out.println();
        double tot = listavenda.calculaTotal();
        int i = listavenda.totalItens();
        System.out.println("O valor total da sua compra de " + i + " itens foi " + tot + " reais");
    }
}
