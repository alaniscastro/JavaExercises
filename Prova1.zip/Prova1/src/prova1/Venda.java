//Alanis Viana Castro e Matheus Freire Henrique Fonseca
package prova1;
import java.util.HashMap;
import java.util.Map;

public class Venda 
{
    private Map<Produto, Integer> listavenda = new HashMap<Produto, Integer>();
    public void adicionar (int quant, Produto produto)
    {
        listavenda.put(produto, quant);
    }
    
    public double calculaTotal ()
    {
        double tot =0;
        for(Map.Entry<Produto, Integer> p : listavenda.entrySet())
        {
            Produto produto = p.getKey();
            tot=tot+(p.getValue()* produto.getValor() );
        }
        return tot;
    }   
    public int totalItens ()
    {
        return listavenda.size();
    }   
}
