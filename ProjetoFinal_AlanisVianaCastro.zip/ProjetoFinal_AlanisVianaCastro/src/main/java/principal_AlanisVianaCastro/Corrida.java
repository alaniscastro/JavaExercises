package principal_AlanisVianaCastro;

public class Corrida 
{
    private final String enderecoInicial;
    private final String enderecoFinal;
    private final double valorCorrida;
    private final Passageiro passageiro;

    public Corrida(String enderecoInicial, String enderecoFinal, double valorCorrida, Passageiro passageiro) {
        this.enderecoInicial = enderecoInicial;
        this.enderecoFinal = enderecoFinal;
        this.valorCorrida = valorCorrida;
        this.passageiro = passageiro;
    }
        
    public double calcularRepasseMotorista(double valorCorrida) {
        return (70 * valorCorrida) / 100;
    }
}
