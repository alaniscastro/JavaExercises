package principal_AlanisVianaCastro;

public class Motorista {
    private final String nome;
    private double faturamento;
    private final Veiculo veiculo;

    public Motorista(String nome, double faturamento, Veiculo veiculo) {
        this.nome = nome;
        this.faturamento = faturamento;
        this.veiculo = veiculo;
    }

    public String getNome() {
        return nome;
    }

    public double getFaturamento() {
        return faturamento;
    }

    public void setFaturamento(double faturamento) {
        this.faturamento = this.faturamento + faturamento;
    }

    public Veiculo getVeiculo() {
        return veiculo;
    }    
}
