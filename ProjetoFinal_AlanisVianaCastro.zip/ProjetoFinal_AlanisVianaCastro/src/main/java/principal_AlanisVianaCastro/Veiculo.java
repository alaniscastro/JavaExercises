package principal_AlanisVianaCastro;

import java.util.ArrayList;

public class Veiculo 
{
    private ArrayList<Corrida> corrida;

    public Veiculo() {
        this.corrida = new ArrayList<>();
    }
    
    public ArrayList<Corrida> getCorrida() {
        return corrida;
    }

    public void setCorrida(ArrayList<Corrida> corrida) {
        this.corrida = corrida;
    }

    public void addCorrida(Corrida corrida) {
        this.corrida.add(corrida);
    }
}