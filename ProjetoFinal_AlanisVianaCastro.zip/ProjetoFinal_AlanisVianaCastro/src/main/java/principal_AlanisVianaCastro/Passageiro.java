package principal_AlanisVianaCastro;

public class Passageiro 
{
    private final String nome;

    public Passageiro(String nome) {
        this.nome = nome;
    }
    
    public String getNome() {
        return nome;
    }
}
