public class Moeda extends Bem
{
    private int nivel;
    
    public Moeda(int quantidade, int nivel) {
        super(quantidade);
        this.nivel = nivel;
    }

    @Override
    public double converterParaDolar(double dolarComercial) 
    {
        double valor = quantidade * nivel * dolarComercial * 0.05;
        return valor;
    }
}
