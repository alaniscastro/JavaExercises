public class Ferramenta extends Bem
{
    private String acao;
    
    public Ferramenta(int quantidade, String acao) {
        super(quantidade);
        this.acao = acao;
    }

    @Override
    public double converterParaDolar(double dolarComercial) 
    {
        double acaoValor = 1;
        if (acao.equals("defesa") || acao.equals("escudo") || acao.equals("bloqueio"))
        {
            acaoValor = 0.3;
        }
        if (acao.equals("destruição") || acao.equals("desativação") || acao.equals("inativação"))
        {
            acaoValor = 0.2;
        }
        if (acao.equals("invisibilidade") || acao.equals("autodesativação"))
        {
            acaoValor = 0.1;
        }
        double valor = quantidade * acaoValor * dolarComercial * 0.05;
        return valor;
    }   
}
