public class Inventario 
{
    public static void main (String [] args)
    {
        Situacao pessoa1 = new Situacao();
        pessoa1.add(new Seguidor (5000, 5));
        pessoa1.add(new Vida (7, "válida"));
        pessoa1.add(new Moeda (1000000, 7));
        pessoa1.add(new Recurso (2, "força", 7));
        pessoa1.add(new Ferramenta (4, "escudo"));
        pessoa1.add(new Cenario (8, 78, 2500));
        
        Situacao pessoa2 = new Situacao();
        pessoa2.add(new Seguidor (7000, 7));
        pessoa2.add(new Vida (3, "inválida"));
        pessoa2.add(new Moeda (5000, 1));
        pessoa2.add(new Recurso (4, "poder", 2));
        pessoa2.add(new Ferramenta (8, "desativação"));
        pessoa2.add(new Cenario (1, 87, 250));
        
        double inventarioPessoa1 = pessoa1.calculaValorInventario();
        double inventarioPessoa2 = pessoa2.calculaValorInventario();
        
        System.out.println("O valor do inventário da pessoa 1 é " + inventarioPessoa1);
        System.out.println("O valor do inventário da pessoa 2 é " + inventarioPessoa2);
    }   
}
