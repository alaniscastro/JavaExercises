import java.util.ArrayList;

public class Situacao 
{
    private ArrayList <Bem> bens;
    
    public Situacao()
    {
        bens = new ArrayList<Bem>();
    }
    
    public void add (Bem bem)
    {
        bens.add(bem);
    }
    
    public double calculaValorInventario()
    {
        double valorTotal = 0;
        for (Bem bem : bens)
        {
            valorTotal = valorTotal + bem.converterParaDolar(5.53);
        }
        return valorTotal;
    }
}
