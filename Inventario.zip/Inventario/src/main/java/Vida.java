public class Vida extends Bem
{
    private String validade;
    
    public Vida(int quantidade, String validade) 
    {
        super(quantidade);
        this.validade = validade;
    }

    @Override
    public double converterParaDolar(double dolarComercial) 
    {
        if (validade.equals("válida"))
        {
            quantidade = quantidade;
        }
        else
        {
            quantidade = 0;
        }
        double valor = quantidade * dolarComercial * 0.2;
        return valor;
    }   
}
