public class Recurso extends Bem
{
    private String tipo;
    private int nivel;
    
    public Recurso (int quantidade, String tipo, int nivel) {
        super(quantidade);
        this.tipo = tipo;
        this.nivel = nivel;
    }

    @Override
    public double converterParaDolar(double dolarComercial) 
    {
        if (tipo.equals("força"))
        {
            nivel = nivel * 2;
        }
        
        if (tipo.equals("poder"))
        {
            nivel = nivel * 5;
        }
        
        double valor = quantidade * nivel * dolarComercial * 0.05;
        return valor;
    }
}
