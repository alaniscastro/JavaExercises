public class Cenario extends Bem
{
    private int nivel;
    private int tamanho;
    
    public Cenario(int quantidade, int nivel, int tamanho) {
        super(quantidade);
        this.nivel = nivel;
        this.tamanho = tamanho;
    }

    @Override
    public double converterParaDolar(double dolarComercial) 
    {
        double valor = quantidade * nivel * tamanho * dolarComercial * 0.05;
        return valor;
    }
}
