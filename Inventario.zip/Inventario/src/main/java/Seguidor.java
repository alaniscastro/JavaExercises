public class Seguidor extends Bem 
{
    private int fatorImpacto;
    
    public Seguidor(int quantidade, int fatorImpacto) {
        super(quantidade);
        this.fatorImpacto = fatorImpacto;
    }

    @Override
    public double converterParaDolar(double dolarComercial) 
    {
        double valor = quantidade * fatorImpacto * dolarComercial * 0.05; //sendo 0.05 o fato conversor estabelecido no enunciado
        return valor;
    }
}
