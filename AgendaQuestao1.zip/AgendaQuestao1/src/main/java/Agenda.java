import java.util.ArrayList;

public class Agenda 
{
    private ArrayList<Contato> agenda = new ArrayList();
    
    public void adicionar (Contato contato)
    {
        agenda.add(contato);
    }
    public int numeroTotal ()
    {
        int i; 
        i=agenda.size();
        return i;
    }
    public void exibirContato(String nome)
    {
        for (int i=0; i<agenda.size(); i++)
        {
            if (agenda.get(i).getNome().contains(nome))
            {
                System.out.println("Nome: " + agenda.get(i).getNome() + "\nTelefone: " + agenda.get(i).getTelefone() + "\nEmail: " + agenda.get(i).getEmail());
            }
        }
    }
    public void excluirContato(String nome)
    {
        for (int i=0; i<(agenda.size()); i++)
        {
            if (agenda.get(i).getNome().contains(nome))
            {
                agenda.remove(i);
            }
        }
    }
    public void exibirTudo()
    {
        for (int i=0; i<(agenda.size()); i++)
        {
            System.out.println("Nome: " + agenda.get(i).getNome() + "\nTelefone: " + agenda.get(i).getTelefone() + "\nEmail: " + agenda.get(i).getEmail());
        }
    }    
}