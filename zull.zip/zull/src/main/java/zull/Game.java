package zull;

public class Game 
{
    private Parser parser;
    private Room currentRoom;
        
    public Game() 
    {
        createRooms();
        parser = new Parser();
    }
    
    private void createRooms()
    {
        Room outside, theatre, pub, lab, office, basement, attic;
      
        outside = new Room("outside the main entrance of the university");
        theatre = new Room("in a lecture theatre");
        pub = new Room("in the campus pub");
        lab = new Room("in a computing lab");
        office = new Room("in the computing admin office");
        basement = new Room("in the basement");
        attic = new Room("in the attic");
        
        outside.setExits(null, theatre, lab, pub, null, null);
        theatre.setExits(null, null, null, outside, null, null);
        pub.setExits(null, outside, null, null, null, null);
        lab.setExits(outside, office, null, null, null, null);
        office.setExits(null, null, null, lab, attic, basement);
        basement.setExits(null, null, null, null, office, null);
        attic.setExits(null, null, null, null, null, office);
                
        outside.setFeatures("the lake monster", "the guardian of the university");
        outside.addItem("key");
        theatre.setFeatures(null, "an actress");
        theatre.addItem("script");
        pub.setFeatures(null, "a friend");
        pub.addItem("beer");
        lab.setFeatures("the lava monster", "a teacher");
        lab.addItem("laptop");
        office.setFeatures(null, null);
        basement.setFeatures("a big monster", "a prisioner of the big monster");
        basement.addItem("gun");
        attic.setFeatures(null, null);

        currentRoom = outside;
    }
    
    public void play() 
    {            
        System.out.println();
        System.out.println(" *** Welcome to Adventure! *** ");
        System.out.println("Adventure is a new, incredibly boring adventure game.");
        System.out.println("Type 'help' if you need help.");
        System.out.println();
        boolean finished = false;
        while (! finished) 
        {
            System.out.println("You are " + currentRoom.getDescription());
            Command command;
            command = parser.getCommand();
            finished = processCommand(command);
        }
        System.out.println("Thank you for playing.  Goodbye.");
    }
    
    private boolean processCommand(Command command) 
    {
        boolean wantToQuit = false;

        if(command.isUnknown()) {
            System.out.println("I don't know what you mean...");
            return false;
        }

        String commandWord = command.getCommandWord();
        if (commandWord.equals("help"))
            printHelp();
        else if (commandWord.equals("look"))
            goLook();
        else if (commandWord.equals("go"))
            goRoom(command);
        else if (commandWord.equals("eat"))
            goEat();
        else if (commandWord.equals("quit"))
            wantToQuit = quit(command);

        return wantToQuit;
    }
    
    private void goRoom(Command command) 
    {
        if(!command.hasSecondWord()) 
        {
            System.out.println("Go where?");
            return;
        }
        String direction = command.getSecondWord();

        // Try to leave current room.
        Room nextRoom = null;
        if(direction.equals("north"))
            nextRoom = currentRoom.getExit("north");
        if(direction.equals("east"))
            nextRoom = currentRoom.getExit("east");
        if(direction.equals("south"))
            nextRoom = currentRoom.getExit("south");
        if(direction.equals("west"))
            nextRoom = currentRoom.getExit("west");
        if(direction.equals("up"))
            nextRoom = currentRoom.getExit("up");
        if(direction.equals("down"))
            nextRoom = currentRoom.getExit("down");

        if (nextRoom == null)
            System.out.println("There is no door!");
        else {
            currentRoom = nextRoom;
        }
    }
    
    private void printHelp() 
    {
        System.out.println("You are lost. You are alone. You wander");
        System.out.println("around at the university.");
        System.out.println();
        System.out.println("Your command words are:");
        System.out.println("go quit help look eat");
    }
    
    private boolean quit(Command command) 
    {
        if(command.hasSecondWord()) {
            System.out.println("Quit what?");
            return false;
        }
        else
            return true;  // signal that we want to quit
    }
    
    private void goLook() 
    {
        currentRoom.printFeatures();
        currentRoom.printItems();
        System.out.print("Exits: ");
        currentRoom.showExits();
    }
    
    private void goEat() 
    {
        System.out.print("You ate so you are not hungry anymore");
    }
}