package zull;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Room 
{
    public String description;
    public String name;
    private Map<String, Room> exits = new HashMap<String, Room>();
    private Map<String, String> features = new HashMap<String, String>();
    private ArrayList <String> items = new ArrayList();

    public Room(String description) 
    {
        this.description = description;
    }
    
    public void addItem (String item)
    {
        items.add(item);
    }

    public void setExits(Room north, Room east, Room south, Room west, Room up, Room down) 
    {
        if(north != null)
            exits.put("north", north);
        if(east != null)
            exits.put("east", east);
        if(south != null)
            exits.put("south", south);
        if(west != null)
            exits.put("west", west);
        if(up != null)
            exits.put("up", up);
        if(down != null)
            exits.put("down", down);
    }
    
    public void setFeatures(String monster, String person) 
    {
        if(monster != null)
            features.put("monster", monster);
        if(person != null)
            features.put("player", person);
    }
    
    public void printFeatures()
    {
        for(Map.Entry<String, String> r : features.entrySet())
        {
            if (r.getKey().equals("monster") && r.getValue() != null)
            {
                System.out.println("Oh no! You found " + r.getValue());
            }
            if (r.getKey().equals("player") && r.getValue() != null)
            {
                System.out.println("You found " + r.getValue());
            }
        }
        System.out.println();
    }
    
    public void showExits()
    {
        for(Map.Entry<String, Room> r : exits.entrySet())
        {
            if (r != null)
            {
                System.out.println(r.getKey());
            }
        }
    }
    
    public Room getExit(String direction)
    {         
        Room r = exits.get(direction);       
        if (r != null)
        {
            return r;
        }
        return null;
    }
    
    public void printItems()
    {
        System.out.println("Items:");
        for (int i=0; i<(items.size()); i++)
        {
            System.out.println(items.get(i));
        }
    }

    public String getDescription()
    {
        return description;
    }

    public String getName()
    {
        return name;
    }

}