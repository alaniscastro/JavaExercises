package zull;

public class InvalidCommandException {
    void invalidCommand()
    {
        System.out.println("Invalid Command");
    }
}
