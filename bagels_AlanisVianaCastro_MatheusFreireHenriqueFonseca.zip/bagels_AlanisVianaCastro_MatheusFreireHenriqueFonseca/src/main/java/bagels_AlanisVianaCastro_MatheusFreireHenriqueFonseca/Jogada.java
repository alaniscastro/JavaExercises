/*
Alanis Viana Castro e Matheus Freire Henrique Fonseca
*/
package bagels_AlanisVianaCastro_MatheusFreireHenriqueFonseca;

import java.util.ArrayList;

public class Jogada 
{
    private int num_A; //número a ser adivinhado
    private int num_J; //numero jogado
    private String feedback;

    public Jogada(int num_A, int num_J) {
        this.num_A = num_A;
        this.num_J = num_J;
    }
    
    public String getFeedback() {
        return feedback;
    }
    
    public int getNum_J() {
        return num_J;
    }

    public String tentativa (int num_A, int num_J)
    {
        int vetorA[] = new int [3];
        int vetorJ[] = new int [3];

        int divisaoA = num_A;
        int divisaoJ = num_J;

        String[] vA = String.valueOf(num_A).split("");
        for (int i=2; i>=0; i--){

            vetorA [i] = ((divisaoA)%10);
            vetorJ [i] = ((divisaoJ)%10);

            divisaoA = divisaoA/10;
            divisaoJ = divisaoJ/10;
        }

        ArrayList<String> result  = new ArrayList<String>();

        for (int i=0; i<3; i++){
            for (int j=0; j<3; j++){
                if (vetorA[i] == vetorJ[j]){
                    if (i==j){
                        result.add("Fermi");
                    }
                    else
                        result.add("Pico");
                }
            }
        }
        if (result.isEmpty())
            feedback = "Bagels";
        else
            feedback = String.join(" ", result);
        return feedback;
    }   
}
