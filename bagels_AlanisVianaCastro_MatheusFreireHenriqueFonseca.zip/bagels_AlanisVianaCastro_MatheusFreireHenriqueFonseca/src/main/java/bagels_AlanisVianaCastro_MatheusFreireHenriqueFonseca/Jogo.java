/*
Alanis Viana Castro e Matheus Freire Henrique Fonseca
*/

package bagels_AlanisVianaCastro_MatheusFreireHenriqueFonseca;

import java.util.Scanner;

public class Jogo 
{
    public static void main (String [] args)
    {
        Scanner input = new Scanner (System.in);
        int exitCode = 0; 
        System.out.println("******** BAGEL ********");
        System.out.println("Insira o número a ser adivinhado:");
        int num_A = input.nextInt();
        Bagels jogadas = new Bagels();
        
        while (exitCode != 1)
        {
            System.out.println("Insira sua tentativa de adivinhar:");
            int num_J = input.nextInt();
            Jogada jogada = new Jogada(num_A, num_J);
            jogada.tentativa(num_A, num_J);
            exitCode = jogadas.registraJogada(jogada);
            jogadas.exibirJogada(jogada); 
        }
        System.out.println("Parabéns! Você adivinhou");
        System.out.println("Estatísticas do jogo:");
        jogadas.exibirEstatistica(); 
    }
}