/*
Alanis Viana Castro e Matheus Freire Henrique Fonseca
*/
package bagels_AlanisVianaCastro_MatheusFreireHenriqueFonseca;

import java.util.ArrayList;

public class Bagels 
{
    private ArrayList<Jogada> jogadas = new ArrayList();
   
    public int registraJogada(Jogada jogada){
        jogadas.add(jogada);
        if (jogada.getFeedback().equals("Fermi Fermi Fermi"))
        {
            return 1;
        }
        return 0;
    }
    public void exibirJogada(Jogada jogada){
        System.out.println("Feedback: " + jogada.getFeedback());
    }
    public void exibirEstatistica(){
        for (int i=0; i<(jogadas.size()); i++){
            int jog = i+1;
            System.out.println("Na jogada de número " + jog + " o número tentado foi " + jogadas.get(i).getNum_J() + " e a resposta obtida foi " + jogadas.get(i).getFeedback());
        }
    }
}