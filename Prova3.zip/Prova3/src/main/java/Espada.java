//Alanis Viana Castro e Matheus Freire Henrique Fonseca

public class Espada 
{
    private String descricao;
    private int valor;

    public Espada (String descricao, int valor) {
        this.descricao = descricao;
        this.valor = valor;
    }    

    public int getValor() {
        return valor;
    }

    public String getDescricao() {
        return descricao;
    }
}
