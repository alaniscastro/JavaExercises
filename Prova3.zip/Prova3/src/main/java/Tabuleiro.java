//Alanis Viana Castro e Matheus Freire Henrique Fonseca

public class Tabuleiro 
{
    private Espada[][] tabuleiro = new Espada[13][13];

    public void adicionarEspada (Espada espada, int linha, int coluna)
    {
        tabuleiro[linha][coluna] = espada;
    }
    
    public Espada adicionarJogada (int linha,  int coluna)
    {
        return tabuleiro[linha][coluna];
    }
    
    public boolean checaVazio (int linha, int coluna)
    {
        return (tabuleiro[linha][coluna] == null);
    }
}