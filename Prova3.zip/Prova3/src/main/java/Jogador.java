//Alanis Viana Castro e Matheus Freire Henrique Fonseca

public class Jogador 
{
    private int pontosOponente;
    private String nome;
    private Tabuleiro meuTabuleiro;
    
    public Jogador(String nome) {
        meuTabuleiro = new Tabuleiro();
        pontosOponente = 0;
        this.nome = nome;
    } 

    public String getNome() {
        return nome;
    }

    public boolean EstaVivo() {
        return (pontosOponente < 155);
    }
    
    public void adicionarEspada(Espada espada, int linha, int coluna)
    {
        meuTabuleiro.adicionarEspada(espada, linha, coluna);
    }
    
    public Espada adicionarJogada(int linha, int coluna)
    {
        Espada e = meuTabuleiro.adicionarJogada(linha, coluna);
        if (e!= null)
            pontosOponente+=e.getValor();
        return e;
    }
    public boolean validaJogada (int linha, int coluna)
    {        
        if ((linha>=0)&&(linha<=13))
            if ((coluna>=0) && (coluna<=13))
                    return true;        
        return false;
    }
    
    public boolean validaPosicao(int linha, int coluna)
    {
        return meuTabuleiro.checaVazio(linha, coluna);
    }
}
