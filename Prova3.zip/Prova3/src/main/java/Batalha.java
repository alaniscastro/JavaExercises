//Alanis Viana Castro e Matheus Freire Henrique Fonseca

import java.util.ArrayList;
import java.util.Scanner;

public class Batalha 
{
    public static void main (String [] args)
    {
        Scanner input = new Scanner (System.in);
        String nome;
        System.out.println("Bem vindo ao jogo Batalha!");
        System.out.println("");
        System.out.println("Insira o nome do jogador 1:");
        nome = input.next();
        Jogador jog1 = new Jogador(nome);
        System.out.println("Insira o nome do jogador 2:");
        nome = input.next();
        Jogador jog2 = new Jogador(nome);
        ArrayList<Espada> espadas = new ArrayList(); 
        
        int coluna = 0;
        int linha = 0;
       //cria um array de espadas
        espadas.add(new Espada ("Espada de ouro", 50));
        espadas.add(new Espada ("Espada de bronze", 40));
        espadas.add(new Espada ("Espada de platina", 30));
        espadas.add(new Espada ("Espada de gelo", 20));
        espadas.add(new Espada ("Espada de alumínio", 10));
        espadas.add(new Espada ("Espada de madeira", 5));
        
        boolean validaJogada = false;
        Jogador jogDaVez= jog1;
        for(int i=1;i<3;i++) 
        {
            String linha_s;
            System.out.println("Vez do jogador " + jogDaVez.getNome() + " posicionar suas espadas"); 
            
            for (int j=0; j<espadas.size(); j++)
            {
                validaJogada = false;
                while (!validaJogada)
                {
                    linha = LeEntrada("Insira o número da linha para posicionar sua " + espadas.get(j).getDescricao(),false);
                    coluna = LeEntrada("Insira a letra da coluna para posicionar sua " + espadas.get(j).getDescricao(),true);
                    
                    validaJogada = jogDaVez.validaJogada(linha, coluna) && jogDaVez.validaPosicao(linha, coluna);
                    if (!validaJogada)
                        System.out.println("Posição inválida");
                }
                jogDaVez.adicionarEspada(espadas.get(j), linha, coluna);
            } 
            jogDaVez = jog2;
            System.out.println("");
        }

        jogDaVez= jog1;
        while (jog1.EstaVivo() && jog2.EstaVivo())
        {
            String linha_s;
            validaJogada = false;
            while (!validaJogada)
            {
                linha = LeEntrada("Insira o número da linha onde o jogador " + jogDaVez.getNome() + " deseja procurar a espada adversária",false); 
                coluna = LeEntrada("Insira a letra da coluna onde o jogador " + jogDaVez.getNome() + " deseja procurar a espada adversária",true);
                validaJogada = jogDaVez.validaJogada(linha, coluna);
                if (!validaJogada)
                    System.out.println("Posição inválida");  
            }
            jogDaVez = (jogDaVez == jog1 ? jog2 : jog1);
            
            Espada e = jogDaVez.adicionarJogada(linha, coluna);
            if (e != null)
                System.out.println("Você acertou a " + e.getDescricao() + " e fez " + e.getValor() + " pontos");
        }
        
        System.out.println("O jogador " + (jog1.EstaVivo()?jog1.getNome():jog2.getNome()) +" ganhou");
    } 
    
    public static int LeEntrada (String msg, boolean charToInt)
    {
        int i=0;
        Scanner input = new Scanner (System.in);
        System.out.println(msg); 
        String s = input.next();
        
        if(charToInt) {
            i = (int)s.toUpperCase().charAt(0) - (int) 'A';
        }
        else{
            try {
               i = Integer.parseInt(s);
            }
            catch (NumberFormatException e)
            {
               i = 14;
            }
        }
        return i;
    }
}