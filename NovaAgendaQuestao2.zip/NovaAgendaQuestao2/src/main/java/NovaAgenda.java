import java.util.HashMap;
import java.util.Map;

public class NovaAgenda 
{
    private Map<String,Contato> agenda = new HashMap<String, Contato>();
    
    public void adicionar (Contato contato)
    {
        agenda.put(contato.getNome(), contato);
    }
    public int numeroTotal ()
    {
        return agenda.size();
    }
    public void exibirContato(String nome)
    {         
        Contato c = agenda.get(nome);
        
        if (c != null)
        {
            System.out.println("Nome: " + c.getNome() + "\nTelefone: " + c.getTelefone() + "\nEmail: " + c.getEmail());
        }
    }
    public void excluirContato(String nome)
    {
        agenda.remove(nome);
    }
    public void exibirTudo()
    {
        for(Map.Entry<String, Contato> c : agenda.entrySet())
        {
            Contato contato = agenda.get(c.getKey());
            System.out.println("Nome: " + contato.getNome() + "\nTelefone: " + contato.getTelefone() + "\nEmail: " + contato.getEmail());
            System.out.println();
        }
    }    
}