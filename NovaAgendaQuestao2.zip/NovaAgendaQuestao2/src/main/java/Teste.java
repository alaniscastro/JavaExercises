import java.util.Scanner;

public class Teste 
{
    public static void main (String [] args)
    {
        System.out.println("==================================\n" +
        "Selecione a opção desejada:\n" +
        "(1) - Insere novo contato na agenda\n" +
        "(2) - Exibe o número total de contatos da agenda\n" +
        "(3) - Exibe um contato (pesquisa pelo nome)\n" +
        "(4) - Exclui um contato (pesquisa pelo nome)\n" +
        "(5) - Exibe todos os contatos da agenda\n" +
        "(0) - Sair\n" +
        "==================================");
        Scanner input = new Scanner (System.in);
        int x = input.nextInt();
        NovaAgenda agenda = new NovaAgenda();
        while (x!=0)
        {
            if (x==1)
            {   
                System.out.println("Insira o nome do contato que deseja adicionar");
                String nome = input.next();
                System.out.println("Insira o número de telefone do contato:");
                String telefone = input.next();
                System.out.println("Insira o email do contato que deseja adicionar");
                String email = input.next();
                Contato contato = new Contato(telefone, nome, email);
                agenda.adicionar(contato);
            }
            if (x==2)
            {
                System.out.println("Você possui "+ agenda.numeroTotal()+ " contatos");
            }
            if (x==3)
            {
                System.out.println("Insira o nome do contato que deseja visualizar:");
                String nome = input.next();
                agenda.exibirContato(nome);
            }
            if (x==4)
            {
                System.out.println("Insira o nome do contato que deseja excluir:");
                String nome = input.next();
                agenda.excluirContato(nome);
                System.out.println(nome + " foi excluído da Agenda");
            }
            if (x==5)
            {
                agenda.exibirTudo();
            }
            System.out.println("==================================\n" +
            "Selecione a opção desejada:\n" +
            "(1) - Insere novo contato na agenda\n" +
            "(2) - Exibe o número total de contatos da agenda\n" +
            "(3) - Exibe um contato (pesquisa pelo nome)\n" +
            "(4) - Exclui um contato (pesquisa pelo nome)\n" +
            "(5) - Exibe todos os contatos da agenda\n" +
            "(0) - Sair\n" +
            "==================================");
            x = input.nextInt();
        }
        System.out.println("Agenda fechada");
    }
}