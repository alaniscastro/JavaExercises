import java.security.SecureRandom;

public class Baralho 
{
    private final String[] naipes = {"Ouros", "Copas", "Espada", "Paus"}; 
    private final Carta[] baralho;
    private final SecureRandom random = new SecureRandom();
    
    public Baralho()
    {
        baralho = new Carta[52];
        for(String naipe : naipes)
        {
            for(int i=1; i<14; i++)
            {
                baralho[i-1] = new Carta(naipe, i);
            }
        }
    } 
    
    public void embaralhar ()
    {
        int posicao = 0;
        Carta x;
        for(int i=0; i<baralho.length; i++)
        {
            posicao = random.nextInt(51);
            x = baralho [i];
            baralho[i] = baralho[posicao];
            baralho[posicao] = x;
        }
    }
    
    public Carta[] distribuir(int numero)
    {
        Carta[] x = new Carta[numero];
        for(int i=0, j=0; j<numero; i++)
        {
            if(baralho[i] != null)
            {
                x[j]=baralho[i];
                baralho[i] = null;
                j++;
            }
        }
        return x;
    }   
} 