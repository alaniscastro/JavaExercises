public class Jogador 
{
    private Carta[] cartas;
    
    public Carta[] getCartas() 
    {
        return cartas;
    }
    public void setCartas(Carta[] cartas) 
    {
        this.cartas = cartas;
    }
    
    public Carta jogar()
    {
        Carta maior = new Carta();
        for(Carta carta : cartas){
            if(carta.compararValor(maior) == 1){
                maior = carta;
            }
        }
        return maior;
    }
}