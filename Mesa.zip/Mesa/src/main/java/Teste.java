import java.util.Scanner;

public class Teste 
{
    public static void main (String [] args)
    {
        while (true)
        {
            Baralho baralho = new Baralho();
            Jogador jogadorA = new Jogador();
            Jogador jogadorB = new Jogador();
            baralho.embaralhar();
            System.out.println("Mesa embaralhando...\nInforme o número de cartas a distribuir para os jogadores:");
            Scanner input = new Scanner (System.in);
            int numero = input.nextInt();
            System.out.println("Mesa distribui " + numero + " cartas para jogador A e para o jogador B");
            jogadorA.setCartas(baralho.distribuir(numero));
            jogadorB.setCartas(baralho.distribuir(numero));
            System.out.println("O jogador A joga a carta de naipe " + jogadorA.jogar().getNaipe()+ " de valor " + jogadorA.jogar().getValor());
            System.out.println("O jogador B joga a carta de naipe " + jogadorB.jogar().getNaipe()+ " de valor " + jogadorB.jogar().getValor());
            
            if(jogadorA.jogar().compararValor(jogadorB.jogar())== 1)
            {
                System.out.println("Jogador A venceu o jogo");
            }
            else
            {
                if(jogadorA.jogar().compararValor(jogadorB.jogar())== - 1)
                {
                    System.out.println("Jogador B venceu o jogo");
                }
                else
                {
                    if(jogadorA.jogar().getNaipe().equals("Ouros")== true)
                    {
                        System.out.println("Embora o valor de ambas cartas sejam iguais, o jogador A ganhou pois jogou uma carta de Ouros");
                    }
                    else
                    {
                        if(jogadorB.jogar().getNaipe().equals("Ouros")== true)
                        {
                            System.out.println("Embora o valor de ambas cartas sejam iguais, o jogador B ganhou pois jogou uma carta de Ouros");
                        }
                        else
                        {
                            System.out.println("Como os valores das cartas são iguais e nenhum jogador tem carta de Ouros,\n" +
"o jogo ficou empatado!");
                            System.out.println("Jogando novamente...");
                        }
                    }
                }
            }
        }
    }
}