public class Teste 
{
    public static void main (String [] args)
    {
        Carta cartaA; 
        Carta cartaB;
        cartaB = new Carta ();
        cartaA = new Carta ("Espada", 7);
        System.out.println("A carta " + cartaA.getValor() + "-" +cartaA.getNaipe()+ " foi criada");
        cartaB.setValor(2);
        cartaB.getValor();
        cartaB.setNaipe("Coração");
        cartaB.getNaipe();        
        System.out.println("A carta " + cartaB.getValor() + "-" +cartaB.getNaipe()+ " foi criada");
        System.out.printf("Comparando o valor das cartas: ");
        if(cartaA.compararValor(cartaB)==-1)
        {
            System.out.println("-1 - A carta A é menor");
        }
        else 
        {
            if(cartaA.compararValor(cartaB)==0)
            {
            System.out.println("0 - As cartas possuem o mesmo valor");
            }
            else
            {
                System.out.println("1 - A carta A é maior");
            }
        }
        System.out.printf("Comparando do naipe das cartas: ");
        if(cartaA.comparaNaipe(cartaB)==0)
        {
            System.out.println("As cartas não são do mesmo naipe");
        }
        else
        {
            System.out.println("As cartas são do mesmo naipe");
        }
    }   
}
