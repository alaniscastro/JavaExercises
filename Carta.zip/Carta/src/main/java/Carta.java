public class Carta 
{
    private int valor;
    private String naipe;
    
    public Carta()  
    {
        this.valor = 0;
        this.naipe = "";
    }
    
    public Carta (String naipe, int valor)  
    {
        this.valor = valor;
        this.naipe = naipe;
        
    }
    public int compararValor (Carta carta)
    {
        if (this.valor > carta.getValor())
        {
            return 1;
        }
        if (this.valor == carta.getValor())
        {
            return 0;
        }
        if (this.valor > carta.getValor())
        {
            return -1;
        }
        return 0;
    }
    
    public int comparaNaipe (Carta carta)
    {
        if(this.naipe.equals(carta.getNaipe()))
        {
            return 1;
        }
        return 0;
    }
    
    public int getValor()
    {
        return valor;
    }

    public void setValor(int valor)
    {
        if (valor >= 15)
        {
            this.valor = valor%14;
        }
        else    
        {
            this.valor = valor;
        }
    }
    public String getNaipe()
    {
        return naipe;
    }

    public void setNaipe(String naipe)
    {
        this.naipe = naipe;
    }    
}
