public class Triangulo extends Bidimensional
{
    private int base;
    private int altura;
    
    public Triangulo(int base, int altura)
    {
        this.base = base;
        this.altura = altura;
    }
    
    @Override
    public double obterArea() 
    {
        return ((base * altura)/2);
    }
}
