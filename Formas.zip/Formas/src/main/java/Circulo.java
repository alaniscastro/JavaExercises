public class Circulo extends Bidimensional
{
    private int raio;
    
    public Circulo (int raio)
    {
        this.raio = raio;
    }
    
    @Override
    public double obterArea() 
    {
        return (raio * raio * Math.PI);
    }
}