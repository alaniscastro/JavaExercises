public abstract class Bidimensional implements Forma
{
    @Override
    public abstract double obterArea();
}
