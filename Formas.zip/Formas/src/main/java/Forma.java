public interface Forma 
{
    public abstract double obterArea();
}
