public class Esfera extends Tridimensional
{
    private int raio;
    
    public Esfera (int raio)
    {
        this.raio = raio;
    }
    
    @Override
    public double obterArea() 
    {
        return (4 * raio * raio * Math.PI);
    }
    
    @Override
    public double obterVolume() 
    {
        return ((4 * raio * raio * raio * Math.PI)/3);
    }
}