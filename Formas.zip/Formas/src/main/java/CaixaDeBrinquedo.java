import java.util.ArrayList;

public class CaixaDeBrinquedo 
{
    private ArrayList <Forma> formas;
    
    public CaixaDeBrinquedo()
    {
        formas = new ArrayList <Forma>();
    }
    
    public void add (Forma forma)
    {
        formas.add(forma);
    }

    public void descreve(){
        Bidimensional b;
        Tridimensional t;
        double a;
        double v;
        for(Forma f : formas){
            
        try 
        {
            b = (Bidimensional)f;
            a = b.obterArea();
            System.out.println("Eu sou um " + f.getClass().getSimpleName() + " e minha área é " + a);
            
        } catch (Exception e) 
            {
            t = (Tridimensional)f;
            a = t.obterArea();
            v = t.obterVolume();
            System.out.println("Eu sou um " + f.getClass().getSimpleName() + " minha área é " + a + " e meu volume é " + v);
            }           
        }
    }
}
