public class Teste 
{
    public static void main (String [] args)
    {
        CaixaDeBrinquedo caixa = new CaixaDeBrinquedo();
        
        caixa.add(new Triangulo (2, 5));
        caixa.add(new Quadrado(2));
        caixa.add(new Circulo(4));
        caixa.add(new Tetraedro(4));
        caixa.add(new Cubo(5));
        caixa.add(new Esfera(8));
        
        caixa.descreve();
    }
}
