public class Quadrado extends Bidimensional
{
    private int lado;
    
    public Quadrado (int lado)
    {
        this.lado = lado;
    }
    
    @Override
    public double obterArea() 
    {
        return (lado * lado);
    }
}