public class Tetraedro extends Tridimensional
{
    private int lado;
    
    public Tetraedro (int lado)
    {
        this.lado = lado;
    }
    
    @Override
    public double obterArea() 
    {
        return (((lado * lado)/2) * 4);
    }
    
    @Override
    public double obterVolume() 
    {
        return ((lado * lado * lado) * (Math.sqrt(2))/12);
    }
}