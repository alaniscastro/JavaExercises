public abstract class Tridimensional implements Forma
{
    public abstract double obterArea();
    public abstract double obterVolume();
}
