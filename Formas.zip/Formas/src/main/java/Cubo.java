public class Cubo extends Tridimensional
{
    private int lado;
    
    public Cubo (int lado)
    {
        this.lado = lado;
    }
    
    @Override
    public double obterArea() 
    {
        return (6 * lado * lado);
    }
    
    @Override
    public double obterVolume() 
    {
        return (lado * lado * lado);
    }
}