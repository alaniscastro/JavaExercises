//Alanis Viana Castro e Matheus Freire Henrique Fonseca
package main;

public class TesteDetran 
{
    public static void main (String[] args)
    {   
        Detran dt = new Detran();
        Proprietario p1 = new Proprietario("09678543254", "Alanis Viana Castro");
        Proprietario p2 = new Proprietario("09671234554", "Matheus Freire Henrique Fonseca");
        Proprietario p3 = new Proprietario("09678543254", "Alanis Viana Castro");
        
        try{
            dt.adicionaProp(p1);
            System.out.println("Cadastro realizado com sucesso");
        } catch (Exception e){
            System.err.println(e.getMessage());
        }
        
        try{
            dt.adicionaProp(p2);
            System.out.println("Cadastro realizado com sucesso");
        } catch (Exception e){
            System.err.println(e.getMessage());
        }
        
        try{
            dt.adicionaProp(p3);
            System.out.println("Cadastro realizado com sucesso");
        } catch (Exception e){
            System.err.println(e.getMessage());
        }
        
        dt.exibirTudo();
    }
}
