//Alanis Viana Castro e Matheus Freire Henrique Fonseca
package main;

import java.util.ArrayList;

public class Detran 
{
    //private ArrayList <Veiculo> veiculos;    
    private ArrayList<Proprietario> proprietarios = new ArrayList();
    
    public void adicionaProp(Proprietario prop)throws Exception
    {
        if (procuraProprietario(prop.getCpf())) 
        {
            proprietarios.add(prop);
        } 
        else 
        {
           throw new Exception("Contato previamente cadastrado");
        } 
    }
    
    public void exibirTudo() //teste para ver se não adicionou o errado
    {
        for (int i=0; i<(proprietarios.size()); i++)
        {
            System.out.println("Nome: " + proprietarios.get(i).getNome() + "\nCPF: " + proprietarios.get(i).getCpf());
        }
    }    
    //retorna true se não há outro prop com o mesmo cpf e nome
    private boolean procuraProprietario(String cpf) 
    {
        for (int i=0; i<proprietarios.size(); i++)
        {
            if (proprietarios.get(i).getCpf().contains(cpf))
            {
                return false;
            }
        }
        return true;
    }
}
